﻿namespace PROYECTO_SO_CLIENTE_v1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Conectar_btn = new System.Windows.Forms.Button();
            this.Desconectar_btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.C3_tb_ubicacion = new System.Windows.Forms.TextBox();
            this.C3_tb_nombre = new System.Windows.Forms.TextBox();
            this.C2_tb = new System.Windows.Forms.TextBox();
            this.C1_tb = new System.Windows.Forms.TextBox();
            this.C3_rbtn = new System.Windows.Forms.RadioButton();
            this.C2_rbtn = new System.Windows.Forms.RadioButton();
            this.C1_rbtn = new System.Windows.Forms.RadioButton();
            this.Consultar_btn = new System.Windows.Forms.Button();
            this.Login_tb = new System.Windows.Forms.TextBox();
            this.Peticion_lbl = new System.Windows.Forms.Label();
            this.Contra_tb = new System.Windows.Forms.TextBox();
            this.Lista_dt = new System.Windows.Forms.DataGridView();
            this.Invitar_btn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Lista_dt)).BeginInit();
            this.SuspendLayout();
            // 
            // Conectar_btn
            // 
            this.Conectar_btn.Location = new System.Drawing.Point(12, 12);
            this.Conectar_btn.Name = "Conectar_btn";
            this.Conectar_btn.Size = new System.Drawing.Size(135, 46);
            this.Conectar_btn.TabIndex = 0;
            this.Conectar_btn.Text = "CONECTAR";
            this.Conectar_btn.UseVisualStyleBackColor = true;
            this.Conectar_btn.Click += new System.EventHandler(this.Conectar_btn_Click);
            // 
            // Desconectar_btn
            // 
            this.Desconectar_btn.Location = new System.Drawing.Point(153, 12);
            this.Desconectar_btn.Name = "Desconectar_btn";
            this.Desconectar_btn.Size = new System.Drawing.Size(135, 46);
            this.Desconectar_btn.TabIndex = 1;
            this.Desconectar_btn.Text = "DESCONECTAR";
            this.Desconectar_btn.UseVisualStyleBackColor = true;
            this.Desconectar_btn.Click += new System.EventHandler(this.Desconectar_btn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.C3_tb_ubicacion);
            this.panel1.Controls.Add(this.C3_tb_nombre);
            this.panel1.Controls.Add(this.C2_tb);
            this.panel1.Controls.Add(this.C1_tb);
            this.panel1.Controls.Add(this.C3_rbtn);
            this.panel1.Controls.Add(this.C2_rbtn);
            this.panel1.Controls.Add(this.C1_rbtn);
            this.panel1.Location = new System.Drawing.Point(12, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(561, 102);
            this.panel1.TabIndex = 2;
            // 
            // C3_tb_ubicacion
            // 
            this.C3_tb_ubicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3_tb_ubicacion.Location = new System.Drawing.Point(426, 67);
            this.C3_tb_ubicacion.Name = "C3_tb_ubicacion";
            this.C3_tb_ubicacion.Size = new System.Drawing.Size(132, 20);
            this.C3_tb_ubicacion.TabIndex = 7;
            // 
            // C3_tb_nombre
            // 
            this.C3_tb_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3_tb_nombre.Location = new System.Drawing.Point(345, 67);
            this.C3_tb_nombre.Name = "C3_tb_nombre";
            this.C3_tb_nombre.Size = new System.Drawing.Size(76, 20);
            this.C3_tb_nombre.TabIndex = 6;
            // 
            // C2_tb
            // 
            this.C2_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2_tb.Location = new System.Drawing.Point(426, 39);
            this.C2_tb.Name = "C2_tb";
            this.C2_tb.Size = new System.Drawing.Size(132, 20);
            this.C2_tb.TabIndex = 5;
            // 
            // C1_tb
            // 
            this.C1_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1_tb.Location = new System.Drawing.Point(426, 13);
            this.C1_tb.Name = "C1_tb";
            this.C1_tb.Size = new System.Drawing.Size(132, 20);
            this.C1_tb.TabIndex = 4;
            // 
            // C3_rbtn
            // 
            this.C3_rbtn.AutoSize = true;
            this.C3_rbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3_rbtn.Location = new System.Drawing.Point(5, 66);
            this.C3_rbtn.Name = "C3_rbtn";
            this.C3_rbtn.Size = new System.Drawing.Size(334, 21);
            this.C3_rbtn.TabIndex = 2;
            this.C3_rbtn.TabStop = true;
            this.C3_rbtn.Text = "ID DE LAS PARTIDAS GANADAS POR \'X\' EN \'Y\':";
            this.C3_rbtn.UseVisualStyleBackColor = true;
            // 
            // C2_rbtn
            // 
            this.C2_rbtn.AutoSize = true;
            this.C2_rbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2_rbtn.Location = new System.Drawing.Point(5, 39);
            this.C2_rbtn.Name = "C2_rbtn";
            this.C2_rbtn.Size = new System.Drawing.Size(305, 21);
            this.C2_rbtn.TabIndex = 1;
            this.C2_rbtn.TabStop = true;
            this.C2_rbtn.Text = "NÚMERO DE PARTIDAS QUE HA JUGADO:";
            this.C2_rbtn.UseVisualStyleBackColor = true;
            // 
            // C1_rbtn
            // 
            this.C1_rbtn.AutoSize = true;
            this.C1_rbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1_rbtn.Location = new System.Drawing.Point(5, 12);
            this.C1_rbtn.Name = "C1_rbtn";
            this.C1_rbtn.Size = new System.Drawing.Size(416, 21);
            this.C1_rbtn.TabIndex = 0;
            this.C1_rbtn.TabStop = true;
            this.C1_rbtn.Text = "SUMA DE LOS PUNTOS DE LAS PARTIDAS GANADAS POR:";
            this.C1_rbtn.UseVisualStyleBackColor = true;
            // 
            // Consultar_btn
            // 
            this.Consultar_btn.Location = new System.Drawing.Point(438, 64);
            this.Consultar_btn.Name = "Consultar_btn";
            this.Consultar_btn.Size = new System.Drawing.Size(135, 24);
            this.Consultar_btn.TabIndex = 3;
            this.Consultar_btn.Text = "CONSULTAR";
            this.Consultar_btn.UseVisualStyleBackColor = true;
            this.Consultar_btn.Click += new System.EventHandler(this.Consultar_btn_Click);
            // 
            // Login_tb
            // 
            this.Login_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_tb.Location = new System.Drawing.Point(294, 12);
            this.Login_tb.Name = "Login_tb";
            this.Login_tb.Size = new System.Drawing.Size(279, 20);
            this.Login_tb.TabIndex = 3;
            // 
            // Peticion_lbl
            // 
            this.Peticion_lbl.BackColor = System.Drawing.Color.Transparent;
            this.Peticion_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Peticion_lbl.Location = new System.Drawing.Point(13, 61);
            this.Peticion_lbl.Name = "Peticion_lbl";
            this.Peticion_lbl.Size = new System.Drawing.Size(134, 30);
            this.Peticion_lbl.TabIndex = 4;
            this.Peticion_lbl.Text = "PETICIÓN:";
            this.Peticion_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Contra_tb
            // 
            this.Contra_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contra_tb.Location = new System.Drawing.Point(294, 38);
            this.Contra_tb.Name = "Contra_tb";
            this.Contra_tb.Size = new System.Drawing.Size(279, 20);
            this.Contra_tb.TabIndex = 5;
            // 
            // Lista_dt
            // 
            this.Lista_dt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Lista_dt.Location = new System.Drawing.Point(579, 12);
            this.Lista_dt.Name = "Lista_dt";
            this.Lista_dt.Size = new System.Drawing.Size(246, 142);
            this.Lista_dt.TabIndex = 6;
            // 
            // Invitar_btn
            // 
            this.Invitar_btn.Location = new System.Drawing.Point(579, 160);
            this.Invitar_btn.Name = "Invitar_btn";
            this.Invitar_btn.Size = new System.Drawing.Size(246, 36);
            this.Invitar_btn.TabIndex = 7;
            this.Invitar_btn.Text = "INVITAR";
            this.Invitar_btn.UseVisualStyleBackColor = true;
            this.Invitar_btn.Click += new System.EventHandler(this.Invitar_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 208);
            this.Controls.Add(this.Invitar_btn);
            this.Controls.Add(this.Lista_dt);
            this.Controls.Add(this.Consultar_btn);
            this.Controls.Add(this.Contra_tb);
            this.Controls.Add(this.Peticion_lbl);
            this.Controls.Add(this.Login_tb);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Desconectar_btn);
            this.Controls.Add(this.Conectar_btn);
            this.Name = "Form1";
            this.Text = "CLIENTE";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Lista_dt)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Conectar_btn;
        private System.Windows.Forms.Button Desconectar_btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton C3_rbtn;
        private System.Windows.Forms.RadioButton C2_rbtn;
        private System.Windows.Forms.RadioButton C1_rbtn;
        private System.Windows.Forms.TextBox Login_tb;
        private System.Windows.Forms.Label Peticion_lbl;
        private System.Windows.Forms.TextBox Contra_tb;
        private System.Windows.Forms.Button Consultar_btn;
        private System.Windows.Forms.TextBox C1_tb;
        private System.Windows.Forms.TextBox C2_tb;
        private System.Windows.Forms.TextBox C3_tb_ubicacion;
        private System.Windows.Forms.TextBox C3_tb_nombre;
        private System.Windows.Forms.DataGridView Lista_dt;
        private System.Windows.Forms.Button Invitar_btn;
    }
}


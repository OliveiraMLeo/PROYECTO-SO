﻿namespace PROYECTO_SO_CLIENTE_v1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Mensaje_tb = new System.Windows.Forms.TextBox();
            this.Escribir_tb = new System.Windows.Forms.TextBox();
            this.Enviar_btn = new System.Windows.Forms.Button();
            this.Terminar_btn = new System.Windows.Forms.Button();
            this.Nombre_tb = new System.Windows.Forms.TextBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Mensaje_tb
            // 
            this.Mensaje_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mensaje_tb.Location = new System.Drawing.Point(693, 269);
            this.Mensaje_tb.Name = "Mensaje_tb";
            this.Mensaje_tb.ReadOnly = true;
            this.Mensaje_tb.Size = new System.Drawing.Size(281, 20);
            this.Mensaje_tb.TabIndex = 6;
            this.Mensaje_tb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Escribir_tb
            // 
            this.Escribir_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Escribir_tb.Location = new System.Drawing.Point(693, 295);
            this.Escribir_tb.Name = "Escribir_tb";
            this.Escribir_tb.Size = new System.Drawing.Size(281, 20);
            this.Escribir_tb.TabIndex = 7;
            this.Escribir_tb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Enviar_btn
            // 
            this.Enviar_btn.Location = new System.Drawing.Point(693, 321);
            this.Enviar_btn.Name = "Enviar_btn";
            this.Enviar_btn.Size = new System.Drawing.Size(281, 22);
            this.Enviar_btn.TabIndex = 8;
            this.Enviar_btn.Text = "ENVIAR";
            this.Enviar_btn.UseVisualStyleBackColor = true;
            this.Enviar_btn.Click += new System.EventHandler(this.Enviar_btn_Click);
            // 
            // Terminar_btn
            // 
            this.Terminar_btn.Location = new System.Drawing.Point(693, 349);
            this.Terminar_btn.Name = "Terminar_btn";
            this.Terminar_btn.Size = new System.Drawing.Size(281, 22);
            this.Terminar_btn.TabIndex = 9;
            this.Terminar_btn.Text = "TERMINAR";
            this.Terminar_btn.UseVisualStyleBackColor = true;
            this.Terminar_btn.Click += new System.EventHandler(this.Terminar_btn_Click);
            // 
            // Nombre_tb
            // 
            this.Nombre_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nombre_tb.Location = new System.Drawing.Point(693, 243);
            this.Nombre_tb.Name = "Nombre_tb";
            this.Nombre_tb.ReadOnly = true;
            this.Nombre_tb.Size = new System.Drawing.Size(281, 20);
            this.Nombre_tb.TabIndex = 10;
            this.Nombre_tb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 500;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(12, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(630, 372);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 388);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Nombre_tb);
            this.Controls.Add(this.Terminar_btn);
            this.Controls.Add(this.Enviar_btn);
            this.Controls.Add(this.Escribir_tb);
            this.Controls.Add(this.Mensaje_tb);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Mensaje_tb;
        private System.Windows.Forms.TextBox Escribir_tb;
        private System.Windows.Forms.Button Enviar_btn;
        private System.Windows.Forms.Button Terminar_btn;
        private System.Windows.Forms.TextBox Nombre_tb;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
﻿namespace PROYECTO_SO_CLIENTE_v1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Aceptar_btn = new System.Windows.Forms.Button();
            this.Rechazar_btn = new System.Windows.Forms.Button();
            this.Invitacion_tb = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Aceptar_btn
            // 
            this.Aceptar_btn.Location = new System.Drawing.Point(12, 40);
            this.Aceptar_btn.Name = "Aceptar_btn";
            this.Aceptar_btn.Size = new System.Drawing.Size(135, 46);
            this.Aceptar_btn.TabIndex = 1;
            this.Aceptar_btn.Text = "ACEPTAR";
            this.Aceptar_btn.UseVisualStyleBackColor = true;
            this.Aceptar_btn.Click += new System.EventHandler(this.Aceptar_btn_Click);
            // 
            // Rechazar_btn
            // 
            this.Rechazar_btn.Location = new System.Drawing.Point(158, 40);
            this.Rechazar_btn.Name = "Rechazar_btn";
            this.Rechazar_btn.Size = new System.Drawing.Size(135, 46);
            this.Rechazar_btn.TabIndex = 2;
            this.Rechazar_btn.Text = "RECHAZAR";
            this.Rechazar_btn.UseVisualStyleBackColor = true;
            this.Rechazar_btn.Click += new System.EventHandler(this.Rechazar_btn_Click);
            // 
            // Invitacion_tb
            // 
            this.Invitacion_tb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Invitacion_tb.Location = new System.Drawing.Point(12, 12);
            this.Invitacion_tb.Name = "Invitacion_tb";
            this.Invitacion_tb.ReadOnly = true;
            this.Invitacion_tb.Size = new System.Drawing.Size(281, 20);
            this.Invitacion_tb.TabIndex = 5;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(305, 98);
            this.Controls.Add(this.Invitacion_tb);
            this.Controls.Add(this.Rechazar_btn);
            this.Controls.Add(this.Aceptar_btn);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Aceptar_btn;
        private System.Windows.Forms.Button Rechazar_btn;
        private System.Windows.Forms.TextBox Invitacion_tb;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PROYECTO_SO_CLIENTE_v1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public static string Solicitud;

        private void Form2_Load(object sender, EventArgs e)
        {
            Invitacion_tb.Text = "Te ha invitado a jugar: " +Form1.host;
        }

        private void Aceptar_btn_Click(object sender, EventArgs e)
        {
            Solicitud = "SI";
            this.Close();
        }

        private void Rechazar_btn_Click(object sender, EventArgs e)
        {
            Solicitud = "NO";
            this.Close();
        }

    }
}

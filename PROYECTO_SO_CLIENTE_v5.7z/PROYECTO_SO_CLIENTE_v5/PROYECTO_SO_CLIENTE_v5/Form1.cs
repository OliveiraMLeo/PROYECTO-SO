﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace PROYECTO_SO_CLIENTE_v1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //CheckForIllegalCrossThreadCalls = false; //Necesario para evitar el probelma de acceso entre threads
        }

        public static Socket server;
        int conectado = 0;
        Thread atender;
        public static Thread partida;
        DataTable dt;
        public static string jugador, rival, host, guest;
        delegate void DelegadoFondo();
        delegate void DelegadoDataGrid(int numconectados, string [] conectados);

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add("Numero de Conectados");
            dt.Columns.Add("Conectados");
            Lista_dt.DataSource = dt;
        }

        private void AtenderServidor()
        {
            while (true)
            {
                //Recibimos el mensaje del servidor
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                string [] trozos = Encoding.ASCII.GetString(msg2).Split('/');
                int codigo = Convert.ToInt32(trozos[0]);
                string mensaje;

                switch (codigo)
                {
                    case 1:
                        mensaje = trozos[1].Split('\0')[0];

                        if (mensaje == "SI")
                        {
                            DelegadoFondo delFondo = new DelegadoFondo(CambiarFondo);
                            Invoke(delFondo, new object[] { });
                            MessageBox.Show("Conectado.");
                            conectado = 1;
                        }
                        else { MessageBox.Show("No existe tal usuario en la base de datos."); }
                        break;

                    case 2:
                        mensaje = trozos[1].Split('\0')[0];
                        MessageBox.Show(mensaje);
                        break;

                    case 3:
                        mensaje = trozos[1].Split('\0')[0];
                        MessageBox.Show(mensaje);
                        break;

                    case 4:
                        mensaje = trozos[1].Split('\0')[0];
                        MessageBox.Show(mensaje);
                        break;

                    case 5:
                        mensaje = trozos[1].Split('\0')[0];
                        int numconectados = Convert.ToInt32(mensaje.Split('-')[0]);
                        string listaconectados = mensaje.Split('*')[1];
                        string [] conectados = new string [100];

                        if (numconectados > 1)
                            conectados = listaconectados.Split('-');
                        else
                            conectados[0] = listaconectados;

                        DelegadoDataGrid delDataGrid = new DelegadoDataGrid(ActualizarTabla);
                        Lista_dt.Invoke(delDataGrid, new object[] { numconectados, conectados });
                        break;

                    case 6:
                        guest = trozos[1].Split('\0')[0];
                        host = trozos[2].Split('\0')[0];

                        Form Invitacion = new Form2();
                        Invitacion.ShowDialog();

                        mensaje = "6/" + Form2.Solicitud + "/" + guest + "/" + host;
                        byte[] msg3 = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg3);
                        break;

                    case 7:
                        guest = trozos[1].Split('\0')[0];
                        host = trozos[2].Split('\0')[0];

                        if (guest == Login_tb.Text.ToString())
                        {
                            jugador = guest;
                            rival = host;
                        }
                        else
                        {
                            jugador = host;
                            rival = guest;
                        }

                        ThreadStart ts2 = delegate { CrearPartida(); };
                        partida = new Thread(ts2);
                        partida.Start();
                        break;

                    case 8:
                        mensaje = "Se ha rechazado la invitación";
                        MessageBox.Show(mensaje);
                        break;

                    case 9:
                        mensaje = trozos[1].Split('\0')[0];
                        Form3.label = mensaje;
                        break;
                }

            }
        }

        private void CrearPartida()
        {
            Form Partida = new Form3();
            Partida.ShowDialog();
        }

        private void ActualizarTabla(int numconectados, string [] conectados)
        {
            dt = new DataTable();
            dt.Columns.Add("Numero de Conectados");
            dt.Columns.Add("Conectados");
            
            DataRow row = dt.NewRow();
            row["Numero de Conectados"] = numconectados;
            row["Conectados"] = "-";
            dt.Rows.Add(row);

            for (int i = 0; i < numconectados; i++)
            {
                row = dt.NewRow();
                row["Numero de Conectados"] = "-";
                row["Conectados"] = conectados[i];
                dt.Rows.Add(row);
            }
            Lista_dt.DataSource = dt;
            Lista_dt.Refresh();
        }

        private void BorrarTabla()
        {
            dt = new DataTable();
            dt.Columns.Add("Numero de Conectados");
            dt.Columns.Add("Conectados");
            Lista_dt.DataSource = dt;
            Lista_dt.Refresh();
        }

        private void Conectar_btn_Click(object sender, EventArgs e)
        {
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 9070);

            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);
            }
            catch (SocketException ex)
            {
                MessageBox.Show("No se ha podido conectar con el servidor.");
                return;
            }

            //Creamos los threads 
            ThreadStart ts = delegate { AtenderServidor(); };
            atender = new Thread(ts);
            atender.Start();

            string mensaje = "1/"+Login_tb.Text+"/"+Contra_tb.Text;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void Desconectar_btn_Click(object sender, EventArgs e)
        {
            if (conectado == 1)
            {
                string mensaje = "0/";
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Nos deconectamos
                atender.Abort();
                BorrarTabla();
                this.BackColor = Color.Gray;
                server.Shutdown(SocketShutdown.Both);
                server.Close();
            }

        }
        private void Consultar_btn_Click(object sender, EventArgs e)
        {
            if (conectado == 1)
            {
                if (C1_rbtn.Checked)
                {
                    if (C1_tb.Text != "")
                    {
                        string mensaje = "2/" + C1_tb.Text;
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                    }
                    else
                    { MessageBox.Show("Para realizar la consulta, rellene los datos primeros."); } 
                }
                else if (C2_rbtn.Checked)
                {
                    if (C2_tb.Text != "")
                    {
                        string mensaje = "3/" + C2_tb.Text;
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                    }
                    else
                    { MessageBox.Show("Para realizar la consulta, rellene los datos primero."); }
                }
                else if (C3_rbtn.Checked)
                {
                    if ((C3_tb_nombre.Text != "") && (C3_tb_ubicacion.Text != ""))
                    {
                        string mensaje = "4/" + C3_tb_nombre.Text + "/" + C3_tb_ubicacion.Text;
                        byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                        server.Send(msg);
                    }
                    else
                    { MessageBox.Show("Para realizar la consulta, rellene los datos primero."); }
                }
            }
            else { MessageBox.Show("Para realizar una consulta, debe Logearse"); }
        }

        private void Invitar_btn_Click(object sender, EventArgs e)
        {
            string nombre = Lista_dt.CurrentCell.Value.ToString();

            if (conectado == 1)
            {
                string mensaje = "5/" + nombre + "/" + Login_tb.Text;
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else { MessageBox.Show("Para invitar a un jugador, debe Logearse"); }
        }

        private void CambiarFondo()
        {
            this.BackColor = Color.Green;
        }


    }
}

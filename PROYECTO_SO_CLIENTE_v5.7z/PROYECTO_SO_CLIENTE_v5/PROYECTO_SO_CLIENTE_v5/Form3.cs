﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PROYECTO_SO_CLIENTE_v1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }  

        string mensaje;
        public static string label;

        private void Form3_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(@"C:\Users\HP\OneDrive\Escritorio\PROYECTO_SO_CLIENTE_v5\PROYECTO_SO_CLIENTE_v5\Tablero.jpg");
            this.Nombre_tb.Text = "Jugando partida con: " +Form1.rival;
            this.Mensaje_tb.Text = "";
        }

        private void Enviar_btn_Click(object sender, EventArgs e)
        {
            mensaje = "7/" + Form1.rival.ToString() + "/" + Escribir_tb.Text.ToString();
            byte[] msg3 = System.Text.Encoding.ASCII.GetBytes(mensaje);
            Form1.server.Send(msg3);
        }

        private void Terminar_btn_Click(object sender, EventArgs e)
        {
            Form1.partida.Abort();
            this.Close();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            this.Mensaje_tb.Text = label;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
